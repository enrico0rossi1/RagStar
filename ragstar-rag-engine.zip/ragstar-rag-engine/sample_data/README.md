# Sample data

Deliberately varied file structures, to stress-test the loaders:

- `requests_readme.md` — real markdown, from the `psf/requests` GitHub repo. Multiple headers/sections.
- `pride_and_prejudice_excerpt.html` — real HTML, an excerpt of the GITenberg mirror of Jane Austen's *Pride and Prejudice*. Dense prose, tests the HTML-to-text extraction.
- `iris.csv` — real CSV, the classic Iris flower dataset (`mwaskom/seaborn-data`). Tests per-row record chunking.
- `countries.json` — real JSON, a 15-country subset of `mledoze/countries`. Tests list-of-objects JSON chunking.
- `adr_0001.pdf` — a PDF rendering of this project's own ADR-0001. Multi-page, tests per-page PDF extraction and page-number metadata.

Note on `adr_0001.pdf`: the original plan was to grab a real paper from arxiv.org as the PDF sample, but arxiv.org (and wikipedia.org) aren't reachable from this cloud sandbox's network allowlist — only a handful of domains (GitHub, PyPI, etc.) are. Rather than fake it, this PDF was generated from the project's own ADR. On your machine, with normal internet access, swap in any real PDF you like — the loader doesn't care where it came from.

Try it:

```
python -m rag_engine.cli ingest sample_data/
python -m rag_engine.cli query "What breed classifications exist in the iris dataset?"
python -m rag_engine.cli query "What is the capital of the countries in the dataset?"
python -m rag_engine.cli query "Why shouldn't DwarfStar be forked yet, according to the ADR?"
```
