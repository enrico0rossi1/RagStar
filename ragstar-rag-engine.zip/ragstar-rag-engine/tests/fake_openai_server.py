"""A tiny stand-in for an OpenAI-compatible server (Ollama/ds4-server),
used only for the offline smoke test in test_pipeline_smoke.py.

This is NOT part of the shipped rag_engine — it exists purely so the
pipeline's wiring (HTTP calls, request/response shapes, chunk -> embed ->
store -> retrieve -> prompt -> generate) can be verified in this cloud
sandbox, where a real Ollama instance isn't available. It fakes "semantic"
embeddings with a simple word-hashing trick so retrieval correctness can
actually be checked (matching queries should surface matching chunks),
not just "did it crash."
"""
from __future__ import annotations

import hashlib
import json
import re
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

DIM = 512

# A small stopword list so generic connective words don't dominate the toy
# hashing embedding below and drown out the content words that should
# actually distinguish one chunk from another.
_STOPWORDS = {
    "a", "an", "and", "are", "as", "at", "be", "by", "for", "from", "has",
    "have", "in", "into", "is", "it", "its", "of", "on", "or", "that",
    "the", "their", "these", "this", "to", "used", "using", "with",
}


def _hashing_embedding(text: str, dim: int = DIM) -> list[float]:
    vec = [0.0] * dim
    words = [
        w for w in re.findall(r"[a-z0-9]+", text.lower()) if w not in _STOPWORDS
    ]
    for w in words:
        h = int(hashlib.md5(w.encode()).hexdigest(), 16)
        vec[h % dim] += 1.0
    norm = sum(v * v for v in vec) ** 0.5
    if norm:
        vec = [v / norm for v in vec]
    return vec


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):  # silence default request logging
        pass

    def _read_json(self) -> dict:
        length = int(self.headers.get("Content-Length", 0))
        return json.loads(self.rfile.read(length) or b"{}")

    def _respond(self, payload: dict, status: int = 200) -> None:
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        if self.path.endswith("/embeddings"):
            body = self._read_json()
            texts = body.get("input", [])
            data = [
                {"index": i, "embedding": _hashing_embedding(t)}
                for i, t in enumerate(texts)
            ]
            self._respond({"data": data, "model": body.get("model")})
            return

        if self.path.endswith("/chat/completions"):
            body = self._read_json()
            messages = body.get("messages", [])
            user_msg = next(
                (m["content"] for m in reversed(messages) if m["role"] == "user"),
                "",
            )
            sources = re.findall(r"\[source \d+: ([^\]]+)\]", user_msg)
            answer = (
                f"(fake model) I was given {len(sources)} source chunk(s): "
                f"{', '.join(sources) if sources else 'none'}."
            )
            self._respond(
                {"choices": [{"message": {"role": "assistant", "content": answer}}]}
            )
            return

        self._respond({"error": f"unhandled path {self.path}"}, status=404)


class FakeOpenAIServer:
    """Context manager: spins up the stub server on a background thread."""

    def __init__(self):
        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.port = self.httpd.server_port
        self.base_url = f"http://127.0.0.1:{self.port}/v1"
        self._thread: threading.Thread | None = None

    def __enter__(self) -> "FakeOpenAIServer":
        self._thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self._thread.start()
        return self

    def __exit__(self, *exc):
        self.httpd.shutdown()
        self.httpd.server_close()
