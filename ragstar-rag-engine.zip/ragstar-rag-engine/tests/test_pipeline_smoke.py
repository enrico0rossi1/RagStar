"""Offline smoke tests for the RAG pipeline.

Two things get checked, since neither alone is enough:

1. `test_retrieval_correctness` — with a fake but deterministic embeddings
   server, does asking about "cats" actually retrieve the cat chunk over
   the rocket-engine and pasta chunks? This catches wiring bugs (wrong
   axis in the cosine similarity, off-by-one in top-k, chunk/vector
   misalignment) that a "did it crash" test would miss.

2. `test_ingest_all_sample_formats` — does every loader in sample_data/
   (md, html, csv, json, pdf) parse without exploding, and does the whole
   ingest -> query round trip work end to end across all of them at once?

Neither test needs a real Ollama running — they point the pipeline at the
fake stub server in fake_openai_server.py. Real generation quality still
needs to be checked by hand once Ollama is running for real; this only
proves the plumbing is correct.

Run with:  python3 -m tests.test_pipeline_smoke   (from the project root)
"""
from __future__ import annotations

import shutil
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from rag_engine.config import Config
from rag_engine.pipeline import RagPipeline

from tests.fake_openai_server import FakeOpenAIServer

SAMPLE_DATA = Path(__file__).resolve().parent.parent / "sample_data"


class RetrievalCorrectnessTest(unittest.TestCase):
    def test_retrieval_correctness(self):
        with FakeOpenAIServer() as server:
            tmp = Path(tempfile.mkdtemp())
            try:
                cfg = Config(
                    chat_base_url=server.base_url,
                    embed_base_url=server.base_url,
                    index_dir=tmp / "index",
                    chunk_size_chars=500,
                    chunk_overlap_chars=50,
                    top_k=1,
                )
                pipeline = RagPipeline(cfg)

                docs = {
                    "cats.txt": (
                        "Cats are small carnivorous mammals. Domestic cats "
                        "enjoy chasing string and sleeping in sunny spots. "
                        "A group of cats is called a clowder."
                    ),
                    "rockets.txt": (
                        "Rocket engines produce thrust by expelling propellant "
                        "at high velocity. Liquid-fueled rockets use a "
                        "combination of fuel and oxidizer pumped into a "
                        "combustion chamber."
                    ),
                    "pasta.txt": (
                        "Pasta is made from wheat flour and water, formed "
                        "into shapes and boiled. Common shapes include "
                        "spaghetti, penne, and fusilli."
                    ),
                }
                for name, text in docs.items():
                    (tmp / name).write_text(text)
                    pipeline.ingest_path(tmp / name)

                result = pipeline.query("What is a group of cats called?")
                top_source = result.retrieved[0].chunk.source
                self.assertTrue(
                    top_source.endswith("cats.txt"),
                    f"expected cats.txt to rank first, got {top_source} "
                    f"(all: {[r.chunk.source for r in result.retrieved]})",
                )

                result = pipeline.query("How do liquid rocket engines work?")
                top_source = result.retrieved[0].chunk.source
                self.assertTrue(top_source.endswith("rockets.txt"))
            finally:
                shutil.rmtree(tmp, ignore_errors=True)


class VariedFormatIngestTest(unittest.TestCase):
    def test_ingest_all_sample_formats(self):
        self.assertTrue(
            SAMPLE_DATA.exists(), f"sample_data not found at {SAMPLE_DATA}"
        )
        formats_present = {p.suffix.lower() for p in SAMPLE_DATA.glob("*") if p.is_file()}
        expected = {".md", ".html", ".csv", ".json", ".pdf"}
        missing = expected - formats_present
        self.assertFalse(missing, f"sample_data is missing formats: {missing}")

        with FakeOpenAIServer() as server:
            tmp = Path(tempfile.mkdtemp())
            try:
                cfg = Config(
                    chat_base_url=server.base_url,
                    embed_base_url=server.base_url,
                    index_dir=tmp / "index",
                )
                pipeline = RagPipeline(cfg)
                stats = pipeline.ingest_path(SAMPLE_DATA)

                self.assertGreater(stats.documents, 0)
                self.assertGreater(stats.chunks, 0)
                self.assertEqual(len(pipeline.store), stats.chunks)

                # confirm each format actually contributed at least one chunk,
                # not just that ingest didn't crash
                sources = {c.metadata.get("format") for c in pipeline.store._chunks}
                for fmt in ("markdown", "html", "csv", "json", "pdf"):
                    self.assertIn(fmt, sources, f"no chunks came from format={fmt}")

                result = pipeline.query("iris dataset flower measurements")
                self.assertTrue(result.answer)
                self.assertGreater(len(result.retrieved), 0)
            finally:
                shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
