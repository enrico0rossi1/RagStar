"""A small, hand-written client for the OpenAI-compatible /v1/embeddings
endpoint.

Written by hand (plain `requests` calls, no `openai` SDK) so it's obvious
exactly what's being sent and received — that's the whole point of the
"from scratch" approach. Ollama serves this endpoint today; DwarfStar does
not and has no plans to (confirmed against its docs), so this client stays
pointed at Ollama (or another local embedding server) even after the
generation client below moves to ds4-server.
"""
from __future__ import annotations

import requests

from .config import Config


class EmbeddingError(RuntimeError):
    pass


class EmbeddingClient:
    def __init__(self, config: Config):
        self.base_url = config.embed_base_url.rstrip("/")
        self.model = config.embed_model
        self.api_key = config.embed_api_key

    def embed(self, texts: list[str], batch_size: int = 32) -> list[list[float]]:
        """Embed a list of texts, batching requests so a large ingest
        doesn't send one enormous payload."""
        if not texts:
            return []

        vectors: list[list[float]] = []
        for i in range(0, len(texts), batch_size):
            batch = texts[i : i + batch_size]
            vectors.extend(self._embed_batch(batch))
        return vectors

    def embed_one(self, text: str) -> list[float]:
        return self.embed([text])[0]

    def _embed_batch(self, batch: list[str]) -> list[list[float]]:
        url = f"{self.base_url}/embeddings"
        try:
            resp = requests.post(
                url,
                headers={"Authorization": f"Bearer {self.api_key}"},
                json={"model": self.model, "input": batch},
                timeout=120,
            )
        except requests.RequestException as exc:
            raise EmbeddingError(
                f"Could not reach embeddings server at {url}: {exc}\n"
                "Is Ollama running? (`ollama serve`, and "
                f"`ollama pull {self.model}` if you haven't already)"
            ) from exc

        if resp.status_code != 200:
            raise EmbeddingError(
                f"Embeddings request failed ({resp.status_code}): {resp.text}"
            )

        data = resp.json()
        try:
            items = sorted(data["data"], key=lambda d: d.get("index", 0))
            return [item["embedding"] for item in items]
        except (KeyError, TypeError) as exc:
            raise EmbeddingError(
                f"Unexpected embeddings response shape: {data}"
            ) from exc
