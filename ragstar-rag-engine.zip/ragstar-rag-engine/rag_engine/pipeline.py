"""Wires the pieces together: ingest documents -> chunk -> embed -> store,
and query -> retrieve -> assemble prompt -> generate.

This is the one file that knows about the full pipeline shape; every other
module only knows about its own stage. That separation is what makes it
possible to swap the generation backend (Ollama -> DwarfStar) without
touching ingestion, or to swap the chunking strategy without touching
retrieval.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .chunking import chunk_documents
from .config import Config
from .embeddings import EmbeddingClient
from .generation import ChatClient
from .loaders import load_directory, load_document
from .retrieval import RetrievedChunk, Retriever
from .vectorstore import VectorStore


@dataclass
class IngestStats:
    documents: int
    chunks: int


@dataclass
class QueryResult:
    answer: str
    retrieved: list[RetrievedChunk]


class RagPipeline:
    def __init__(self, config: Config | None = None):
        self.config = config or Config()
        self.embedder = EmbeddingClient(self.config)
        self.chat = ChatClient(self.config)
        self.store = VectorStore()

    # -- persistence -----------------------------------------------------

    def load_index(self) -> None:
        self.store = VectorStore.load(self.config.index_dir)

    def save_index(self) -> None:
        self.store.save(self.config.index_dir)

    # -- ingest ------------------------------------------------------------

    def ingest_path(self, path: Path) -> IngestStats:
        path = Path(path)
        docs = load_directory(path) if path.is_dir() else load_document(path)

        chunks = chunk_documents(
            docs, self.config.chunk_size_chars, self.config.chunk_overlap_chars
        )
        if not chunks:
            return IngestStats(documents=len(docs), chunks=0)

        vectors = self.embedder.embed([c.text for c in chunks])
        self.store.add(chunks, vectors)
        self.save_index()
        return IngestStats(documents=len(docs), chunks=len(chunks))

    # -- query ---------------------------------------------------------

    def query(self, question: str, top_k: int | None = None) -> QueryResult:
        retriever = Retriever(self.config, self.embedder, self.store)
        retrieved = retriever.retrieve(question, top_k=top_k)

        context = self._build_context(retrieved)
        messages = [
            {"role": "system", "content": self.config.system_prompt},
            {
                "role": "user",
                "content": (
                    f"Context:\n{context}\n\n"
                    f"Question: {question}\n\n"
                    "Answer using only the context above."
                ),
            },
        ]
        answer = self.chat.chat(messages)
        return QueryResult(answer=answer, retrieved=retrieved)

    def _build_context(self, retrieved: list[RetrievedChunk]) -> str:
        pieces: list[str] = []
        used = 0
        for i, r in enumerate(retrieved):
            tag = f"[source {i + 1}: {r.chunk.source}]"
            piece = f"{tag}\n{r.chunk.text}"
            if used + len(piece) > self.config.max_context_chars and pieces:
                # keep at least one chunk even if it alone exceeds the cap
                break
            pieces.append(piece)
            used += len(piece)
        return "\n\n---\n\n".join(pieces)
