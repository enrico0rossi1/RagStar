"""Retrieval: embed a query, search the vector store, return top-k chunks.

Deliberately tiny — this is "Naive RAG" retrieval (single dense-vector
query, no query rewriting, no reranking, no hybrid keyword search). Those
are the natural "Advanced RAG" upgrades once this baseline is proven to
work end to end; see the ADR for why they matter more on slow local
hardware than they would against a fast cloud API.
"""
from __future__ import annotations

from dataclasses import dataclass

from .chunking import Chunk
from .config import Config
from .embeddings import EmbeddingClient
from .vectorstore import VectorStore


@dataclass
class RetrievedChunk:
    chunk: Chunk
    score: float


class Retriever:
    def __init__(
        self, config: Config, embedder: EmbeddingClient, store: VectorStore
    ):
        self.config = config
        self.embedder = embedder
        self.store = store

    def retrieve(self, query: str, top_k: int | None = None) -> list[RetrievedChunk]:
        k = top_k or self.config.top_k
        query_vector = self.embedder.embed_one(query)
        results = self.store.search(query_vector, top_k=k)
        return [RetrievedChunk(chunk=c, score=s) for c, s in results]
