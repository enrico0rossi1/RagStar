"""A from-scratch vector store: numpy arrays + brute-force cosine
similarity, persisted to disk as a .npy file plus a metadata .json file.

No FAISS, no Chroma, no LanceDB. For a personal dataset (thousands to low
tens of thousands of chunks) brute-force cosine similarity over a numpy
matrix is genuinely fast enough, and — more importantly for a learning
project — it's honest about what "vector search" actually is under the
hood, instead of hiding it behind a library. If this ever needs to scale
past what brute force comfortably handles, swapping in an ANN index later
is a contained change: this class's public interface (`add`, `search`,
`save`, `load`) wouldn't need to change, only its internals.
"""
from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path

import numpy as np

from .chunking import Chunk


class VectorStore:
    def __init__(self):
        self._vectors: np.ndarray | None = None  # shape (n, dim), L2-normalized
        self._chunks: list[Chunk] = []

    def __len__(self) -> int:
        return len(self._chunks)

    def add(self, chunks: list[Chunk], vectors: list[list[float]]) -> None:
        if len(chunks) != len(vectors):
            raise ValueError("chunks and vectors must be the same length")
        if not chunks:
            return

        new = np.array(vectors, dtype=np.float32)
        new = self._normalize(new)

        if self._vectors is None:
            self._vectors = new
        else:
            self._vectors = np.vstack([self._vectors, new])
        self._chunks.extend(chunks)

    def search(
        self, query_vector: list[float], top_k: int
    ) -> list[tuple[Chunk, float]]:
        if self._vectors is None or len(self._chunks) == 0:
            return []

        q = self._normalize(np.array([query_vector], dtype=np.float32))[0]
        # vectors are already L2-normalized, so the dot product IS cosine
        # similarity — no need to divide by norms again at query time.
        scores = self._vectors @ q

        k = min(top_k, len(self._chunks))
        # argpartition for O(n) top-k instead of a full O(n log n) sort
        top_idx = np.argpartition(-scores, k - 1)[:k]
        top_idx = top_idx[np.argsort(-scores[top_idx])]

        return [(self._chunks[i], float(scores[i])) for i in top_idx]

    @staticmethod
    def _normalize(mat: np.ndarray) -> np.ndarray:
        norms = np.linalg.norm(mat, axis=1, keepdims=True)
        norms[norms == 0] = 1.0
        return mat / norms

    def save(self, index_dir: Path) -> None:
        index_dir.mkdir(parents=True, exist_ok=True)
        if self._vectors is not None:
            np.save(index_dir / "vectors.npy", self._vectors)
        else:
            np.save(index_dir / "vectors.npy", np.zeros((0, 0), dtype=np.float32))

        meta = [asdict(c) for c in self._chunks]
        (index_dir / "chunks.json").write_text(
            json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8"
        )

    @classmethod
    def load(cls, index_dir: Path) -> "VectorStore":
        store = cls()
        vectors_path = index_dir / "vectors.npy"
        chunks_path = index_dir / "chunks.json"

        if not vectors_path.exists() or not chunks_path.exists():
            return store  # empty store — caller decides whether that's an error

        vectors = np.load(vectors_path)
        store._vectors = vectors if vectors.size else None

        raw_chunks = json.loads(chunks_path.read_text(encoding="utf-8"))
        store._chunks = [Chunk(**c) for c in raw_chunks]
        return store
