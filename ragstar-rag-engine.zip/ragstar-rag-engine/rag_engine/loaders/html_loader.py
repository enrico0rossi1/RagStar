from __future__ import annotations

from pathlib import Path

from .base import Document, read_text_file


class HtmlLoader:
    """HTML files/pages, stripped down to visible text.

    Uses BeautifulSoup if available; falls back to a crude regex tag
    stripper if it isn't installed, so the pipeline degrades rather than
    hard-failing on a missing optional dependency.
    """

    def load(self, path: Path) -> list[Document]:
        raw = read_text_file(path)
        text = self._extract_text(raw)
        return [
            Document(
                id=f"{path}::whole",
                source=str(path),
                text=text,
                metadata={"format": "html"},
            )
        ]

    @staticmethod
    def _extract_text(raw: str) -> str:
        try:
            from bs4 import BeautifulSoup  # type: ignore

            soup = BeautifulSoup(raw, "html.parser")
            for tag in soup(["script", "style", "noscript"]):
                tag.decompose()
            text = soup.get_text(separator="\n")
        except ImportError:
            import re

            text = re.sub(r"<script.*?</script>", " ", raw, flags=re.S | re.I)
            text = re.sub(r"<style.*?</style>", " ", text, flags=re.S | re.I)
            text = re.sub(r"<[^>]+>", " ", text)

        lines = [ln.strip() for ln in text.splitlines()]
        return "\n".join(ln for ln in lines if ln)
