from __future__ import annotations

from pathlib import Path

from .base import Document


class PdfLoader:
    """PDF files, one Document per page.

    Per-page granularity means retrieval results can point back to a page
    number, which matters more for PDFs than for most formats since
    "where in the document" is usually part of the answer you want.

    Requires `pypdf` (pip install pypdf). Raises a clear error if it's
    missing rather than failing on an unrelated import error deep inside
    the library.
    """

    def load(self, path: Path) -> list[Document]:
        try:
            from pypdf import PdfReader
        except ImportError as exc:
            raise ImportError(
                "PdfLoader requires the 'pypdf' package. Install with: "
                "pip install pypdf"
            ) from exc

        reader = PdfReader(str(path))
        docs: list[Document] = []
        for i, page in enumerate(reader.pages):
            text = (page.extract_text() or "").strip()
            if not text:
                continue
            docs.append(
                Document(
                    id=f"{path}::page{i + 1}",
                    source=str(path),
                    text=text,
                    metadata={"format": "pdf", "page": i + 1},
                )
            )
        return docs
