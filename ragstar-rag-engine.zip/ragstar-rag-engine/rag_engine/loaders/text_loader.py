from __future__ import annotations

from pathlib import Path

from .base import Document, read_text_file


class TextLoader:
    """Plain .txt files. One Document per file."""

    def load(self, path: Path) -> list[Document]:
        text = read_text_file(path)
        return [
            Document(
                id=f"{path}::whole",
                source=str(path),
                text=text,
                metadata={"format": "text"},
            )
        ]
