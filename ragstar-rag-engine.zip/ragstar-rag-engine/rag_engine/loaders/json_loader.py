from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .base import Document


class JsonLoader:
    """JSON files.

    - A top-level list of objects -> one Document per object (record-style
      data, same idea as CsvLoader).
    - Anything else (a single object, nested structure) -> one Document
      for the whole file, pretty-printed so it reads like text.
    """

    def load(self, path: Path) -> list[Document]:
        with path.open("r", encoding="utf-8", errors="replace") as f:
            data = json.load(f)

        if isinstance(data, list) and all(isinstance(x, dict) for x in data):
            docs: list[Document] = []
            for i, obj in enumerate(data):
                text = self._flatten(obj)
                if not text.strip():
                    continue
                docs.append(
                    Document(
                        id=f"{path}::item{i}",
                        source=str(path),
                        text=text,
                        metadata={"format": "json", "item": i},
                    )
                )
            return docs

        return [
            Document(
                id=f"{path}::whole",
                source=str(path),
                text=json.dumps(data, indent=2, ensure_ascii=False),
                metadata={"format": "json"},
            )
        ]

    def _flatten(self, obj: Any, prefix: str = "") -> str:
        lines: list[str] = []
        if isinstance(obj, dict):
            for k, v in obj.items():
                key = f"{prefix}{k}"
                if isinstance(v, (dict, list)):
                    lines.append(self._flatten(v, prefix=f"{key}."))
                else:
                    lines.append(f"{key}: {v}")
        elif isinstance(obj, list):
            for i, v in enumerate(obj):
                lines.append(self._flatten(v, prefix=f"{prefix}[{i}]."))
        else:
            lines.append(f"{prefix.rstrip('.')}: {obj}")
        return "\n".join(lines)
