from __future__ import annotations

import csv
from pathlib import Path

from .base import Document


class CsvLoader:
    """CSV files, one Document per row.

    Each row becomes a small "column: value" text blob. This is the right
    granularity for record-style data (a product catalog, a contact list)
    where a question usually maps to one or a few rows, not the whole
    file — very different retrieval unit than a prose document.
    """

    def load(self, path: Path) -> list[Document]:
        docs: list[Document] = []
        with path.open("r", encoding="utf-8", errors="replace", newline="") as f:
            reader = csv.DictReader(f)
            for i, row in enumerate(reader):
                text = "\n".join(f"{k}: {v}" for k, v in row.items() if k)
                if not text.strip():
                    continue
                docs.append(
                    Document(
                        id=f"{path}::row{i}",
                        source=str(path),
                        text=text,
                        metadata={"format": "csv", "row": i},
                    )
                )
        return docs
