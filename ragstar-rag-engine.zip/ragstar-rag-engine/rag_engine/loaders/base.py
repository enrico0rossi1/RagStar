"""Shared types for document loaders.

A `Document` is one ingested file, still whole (not yet chunked). Loaders
for different formats all produce the same shape so the rest of the
pipeline (chunking, embedding, storage) never has to know or care whether
a document started life as a PDF, a CSV row group, or a markdown file.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Protocol


@dataclass
class Document:
    id: str  # stable id, e.g. "<source>::<part>"
    source: str  # file path or URL this came from
    text: str  # plain text content
    metadata: dict[str, Any] = field(default_factory=dict)


class Loader(Protocol):
    """Anything with a `load(path) -> list[Document]` is a valid loader."""

    def load(self, path: Path) -> list[Document]: ...


def read_text_file(path: Path, encoding: str = "utf-8") -> str:
    return path.read_text(encoding=encoding, errors="replace")
