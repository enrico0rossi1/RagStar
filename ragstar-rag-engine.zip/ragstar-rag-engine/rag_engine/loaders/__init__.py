"""Loader registry: pick the right loader by file extension."""
from __future__ import annotations

from pathlib import Path

from .base import Document, Loader
from .csv_loader import CsvLoader
from .html_loader import HtmlLoader
from .json_loader import JsonLoader
from .markdown_loader import MarkdownLoader
from .pdf_loader import PdfLoader
from .text_loader import TextLoader

_REGISTRY: dict[str, Loader] = {
    ".txt": TextLoader(),
    ".md": MarkdownLoader(),
    ".markdown": MarkdownLoader(),
    ".html": HtmlLoader(),
    ".htm": HtmlLoader(),
    ".pdf": PdfLoader(),
    ".csv": CsvLoader(),
    ".json": JsonLoader(),
}


def get_loader(path: Path) -> Loader:
    ext = path.suffix.lower()
    loader = _REGISTRY.get(ext)
    if loader is None:
        raise ValueError(
            f"No loader registered for extension '{ext}' ({path}). "
            f"Supported: {sorted(_REGISTRY)}"
        )
    return loader


def load_document(path: Path) -> list[Document]:
    return get_loader(path).load(path)


def load_directory(directory: Path) -> list[Document]:
    """Load every supported file found recursively under `directory`."""
    docs: list[Document] = []
    skipped: list[Path] = []
    for path in sorted(directory.rglob("*")):
        if not path.is_file():
            continue
        if path.suffix.lower() not in _REGISTRY:
            skipped.append(path)
            continue
        docs.extend(load_document(path))
    if skipped:
        print(
            f"[loaders] skipped {len(skipped)} unsupported file(s), "
            f"e.g. {skipped[0].name}"
        )
    return docs
