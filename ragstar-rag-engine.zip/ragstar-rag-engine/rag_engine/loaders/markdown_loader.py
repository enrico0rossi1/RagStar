from __future__ import annotations

import re
from pathlib import Path

from .base import Document, read_text_file

_HEADER_RE = re.compile(r"^(#{1,6})\s+(.*)$", re.MULTILINE)


class MarkdownLoader:
    """Markdown files, split into one Document per top-level section.

    Splitting on headers (rather than treating the whole file as one blob)
    gives the chunker natural, semantically meaningful boundaries to start
    from instead of cutting mid-thought at a fixed character count.
    """

    def load(self, path: Path) -> list[Document]:
        text = read_text_file(path)
        headers = list(_HEADER_RE.finditer(text))

        if not headers:
            return [
                Document(
                    id=f"{path}::whole",
                    source=str(path),
                    text=text,
                    metadata={"format": "markdown"},
                )
            ]

        docs: list[Document] = []
        for i, match in enumerate(headers):
            start = match.start()
            end = headers[i + 1].start() if i + 1 < len(headers) else len(text)
            section_text = text[start:end].strip()
            if not section_text:
                continue
            title = match.group(2).strip()
            docs.append(
                Document(
                    id=f"{path}::section{i}",
                    source=str(path),
                    text=section_text,
                    metadata={"format": "markdown", "section_title": title},
                )
            )
        return docs
