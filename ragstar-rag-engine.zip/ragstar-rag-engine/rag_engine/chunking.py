"""Turn Documents into overlapping text Chunks.

This is a plain recursive-splitter: try to break on paragraph boundaries
first, fall back to sentence boundaries, fall back to a hard character cut
only if nothing better is available. Overlap keeps context from being
severed exactly at a chunk boundary (a sentence that explains something
right at the cut point shouldn't lose all its context).

This is "Naive RAG" chunking in the survey's terms — the deliberately
simple baseline. Smarter, structure-aware chunking (markdown headers,
code-aware splitting, semantic chunking) is a natural next step once this
baseline is working end to end.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from .loaders.base import Document

_PARAGRAPH_SPLIT = re.compile(r"\n\s*\n")
_SENTENCE_SPLIT = re.compile(r"(?<=[.!?])\s+")


@dataclass
class Chunk:
    id: str
    doc_id: str
    source: str
    text: str
    chunk_index: int
    metadata: dict[str, Any] = field(default_factory=dict)


def _split_on(pattern: re.Pattern[str], text: str) -> list[str]:
    return [p for p in pattern.split(text) if p.strip()]


def _pack_units(units: list[str], max_chars: int, overlap_chars: int) -> list[str]:
    """Greedily pack small units (paragraphs/sentences) into chunks close
    to `max_chars`, carrying the tail of one chunk into the start of the
    next for overlap."""
    chunks: list[str] = []
    current = ""

    for unit in units:
        candidate = f"{current}\n\n{unit}".strip() if current else unit

        if len(candidate) <= max_chars:
            current = candidate
            continue

        if current:
            chunks.append(current)
            tail = current[-overlap_chars:] if overlap_chars else ""
            current = f"{tail}\n\n{unit}".strip() if tail else unit
        else:
            # a single unit longer than max_chars: hard-split it
            for i in range(0, len(unit), max_chars - overlap_chars):
                chunks.append(unit[i : i + max_chars])
            current = ""

        # after a hard split, `current` may still be too long — re-run
        # the packing check on it once more
        while len(current) > max_chars:
            chunks.append(current[:max_chars])
            current = current[max_chars - overlap_chars :]

    if current.strip():
        chunks.append(current)

    return chunks


def chunk_text(text: str, max_chars: int, overlap_chars: int) -> list[str]:
    text = text.strip()
    if not text:
        return []
    if len(text) <= max_chars:
        return [text]

    paragraphs = _split_on(_PARAGRAPH_SPLIT, text)
    if len(paragraphs) <= 1:
        paragraphs = _split_on(_SENTENCE_SPLIT, text)
    if not paragraphs:
        paragraphs = [text]

    return _pack_units(paragraphs, max_chars, overlap_chars)


def chunk_document(
    doc: Document, max_chars: int, overlap_chars: int
) -> list[Chunk]:
    pieces = chunk_text(doc.text, max_chars, overlap_chars)
    return [
        Chunk(
            id=f"{doc.id}::chunk{i}",
            doc_id=doc.id,
            source=doc.source,
            text=piece,
            chunk_index=i,
            metadata=dict(doc.metadata),
        )
        for i, piece in enumerate(pieces)
    ]


def chunk_documents(
    docs: list[Document], max_chars: int, overlap_chars: int
) -> list[Chunk]:
    chunks: list[Chunk] = []
    for doc in docs:
        chunks.extend(chunk_document(doc, max_chars, overlap_chars))
    return chunks
