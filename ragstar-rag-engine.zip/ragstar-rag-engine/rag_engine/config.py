"""Central configuration for the RAG engine.

Kept as one small dataclass on purpose: every other module takes a Config
instance rather than reaching for globals or environment variables deep
inside its logic. That's what makes swapping the backend (Ollama today,
DwarfStar's ds4-server later) a one-line change instead of a refactor.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Config:
    # --- Generation backend (OpenAI-compatible chat-completions API) ---
    # Ollama's OpenAI-compat endpoint today. Point this at DwarfStar's
    # ds4-server later (e.g. "http://localhost:8080/v1") — nothing else
    # in this codebase needs to change.
    chat_base_url: str = "http://localhost:11434/v1"
    chat_model: str = "llama3.2"
    chat_api_key: str = "ollama"  # Ollama ignores the key; the field just
    # has to be present because the OpenAI client convention expects one.

    # --- Embeddings backend ---
    # DwarfStar does not (and, per its own docs, has no plans to) serve
    # embeddings — this is intentionally a separate backend from chat,
    # and will stay pointed at Ollama (or another local embedding server)
    # even after generation moves to DwarfStar.
    embed_base_url: str = "http://localhost:11434/v1"
    embed_model: str = "nomic-embed-text"
    embed_api_key: str = "ollama"

    # --- Chunking ---
    chunk_size_chars: int = 1200
    chunk_overlap_chars: int = 150

    # --- Retrieval ---
    top_k: int = 4

    # --- Storage ---
    index_dir: Path = field(default_factory=lambda: Path(".ragstar_index"))

    # --- Generation ---
    system_prompt: str = (
        "You are a careful assistant. Answer the user's question using ONLY "
        "the provided context. If the context does not contain the answer, "
        "say so explicitly instead of guessing. Cite which source each part "
        "of your answer came from using the [source] markers given."
    )
    max_context_chars: int = 6000  # hard cap so retrieval doesn't blow the
    # prompt budget on a slow local model — see the ADR's note on latency.

    @classmethod
    def from_env(cls) -> "Config":
        """Build a Config from defaults, overridden by environment
        variables where set. This is the one-line-change mechanism for
        swapping backends: to point generation at DwarfStar's ds4-server
        instead of Ollama, set

            RAGSTAR_CHAT_BASE_URL=http://localhost:8080/v1
            RAGSTAR_CHAT_MODEL=<whatever ds4-server reports at /v1/models>

        and nothing in the codebase needs to change.
        """
        defaults = cls()
        env = os.environ

        def s(name: str, current: str) -> str:
            return env.get(name, current)

        def i(name: str, current: int) -> int:
            return int(env[name]) if name in env else current

        return cls(
            chat_base_url=s("RAGSTAR_CHAT_BASE_URL", defaults.chat_base_url),
            chat_model=s("RAGSTAR_CHAT_MODEL", defaults.chat_model),
            chat_api_key=s("RAGSTAR_CHAT_API_KEY", defaults.chat_api_key),
            embed_base_url=s("RAGSTAR_EMBED_BASE_URL", defaults.embed_base_url),
            embed_model=s("RAGSTAR_EMBED_MODEL", defaults.embed_model),
            embed_api_key=s("RAGSTAR_EMBED_API_KEY", defaults.embed_api_key),
            chunk_size_chars=i("RAGSTAR_CHUNK_SIZE", defaults.chunk_size_chars),
            chunk_overlap_chars=i(
                "RAGSTAR_CHUNK_OVERLAP", defaults.chunk_overlap_chars
            ),
            top_k=i("RAGSTAR_TOP_K", defaults.top_k),
            index_dir=Path(s("RAGSTAR_INDEX_DIR", str(defaults.index_dir))),
        )
