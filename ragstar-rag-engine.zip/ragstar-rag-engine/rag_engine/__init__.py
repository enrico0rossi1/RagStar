"""ragstar rag_engine — a from-scratch RAG pipeline.

Deliberately built without LangChain/LlamaIndex: the point of this project
is to learn how retrieval-augmented generation actually works, not to learn
a framework's abstractions. Every stage (loading, chunking, embedding,
retrieval, generation) is plain, readable Python you can step through.

The generation client speaks the OpenAI-compatible chat-completions API.
Today that's pointed at a local Ollama server; later it can point at
DwarfStar's ds4-server with a one-line config change, because both speak
the same wire format.
"""

__version__ = "0.1.0"
