"""A small, hand-written client for the OpenAI-compatible
/v1/chat/completions endpoint.

This is the piece that matters most for the "evolve with DwarfStar" goal:
it only knows about the standard chat-completions wire format. Point
`chat_base_url` at Ollama today, or at DwarfStar's `ds4-server` later —
this file does not change either way.
"""
from __future__ import annotations

import requests

from .config import Config


class GenerationError(RuntimeError):
    pass


class ChatClient:
    def __init__(self, config: Config):
        self.base_url = config.chat_base_url.rstrip("/")
        self.model = config.chat_model
        self.api_key = config.chat_api_key

    def chat(
        self,
        messages: list[dict[str, str]],
        temperature: float = 0.2,
    ) -> str:
        url = f"{self.base_url}/chat/completions"
        try:
            resp = requests.post(
                url,
                headers={"Authorization": f"Bearer {self.api_key}"},
                json={
                    "model": self.model,
                    "messages": messages,
                    "temperature": temperature,
                    "stream": False,
                },
                timeout=300,
            )
        except requests.RequestException as exc:
            raise GenerationError(
                f"Could not reach chat server at {url}: {exc}\n"
                "Is Ollama running? (`ollama serve`, and "
                f"`ollama pull {self.model}` if you haven't already)"
            ) from exc

        if resp.status_code != 200:
            raise GenerationError(
                f"Chat request failed ({resp.status_code}): {resp.text}"
            )

        data = resp.json()
        try:
            return data["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as exc:
            raise GenerationError(
                f"Unexpected chat response shape: {data}"
            ) from exc
