"""Command-line entry point.

Usage:
    python -m rag_engine.cli ingest <path> [<path> ...]
    python -m rag_engine.cli query "your question"
    python -m rag_engine.cli query "your question" --top-k 6
    python -m rag_engine.cli reset
"""
from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path

from .config import Config
from .embeddings import EmbeddingError
from .generation import GenerationError
from .pipeline import RagPipeline


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="ragstar")
    sub = parser.add_subparsers(dest="command", required=True)

    ingest_p = sub.add_parser("ingest", help="Load, chunk, embed, and index files or directories")
    ingest_p.add_argument("paths", nargs="+", type=Path)

    query_p = sub.add_parser("query", help="Ask a question against the current index")
    query_p.add_argument("question", type=str)
    query_p.add_argument("--top-k", type=int, default=None)
    query_p.add_argument("--show-sources", action="store_true", default=True)

    sub.add_parser("reset", help="Delete the current index")

    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    config = Config.from_env()

    if args.command == "reset":
        if config.index_dir.exists():
            shutil.rmtree(config.index_dir)
            print(f"Deleted index at {config.index_dir}")
        else:
            print("No index to delete.")
        return 0

    pipeline = RagPipeline(config)
    pipeline.load_index()

    if args.command == "ingest":
        try:
            total_docs = total_chunks = 0
            for path in args.paths:
                if not path.exists():
                    print(f"Skipping (not found): {path}", file=sys.stderr)
                    continue
                stats = pipeline.ingest_path(path)
                total_docs += stats.documents
                total_chunks += stats.chunks
                print(f"  {path}: {stats.documents} document(s) -> {stats.chunks} chunk(s)")
            print(
                f"Done. Indexed {total_chunks} chunk(s) from {total_docs} "
                f"document(s). Index size is now {len(pipeline.store)} chunk(s)."
            )
        except EmbeddingError as exc:
            print(f"Ingest failed: {exc}", file=sys.stderr)
            return 1
        return 0

    if args.command == "query":
        if len(pipeline.store) == 0:
            print(
                "Index is empty — run `ingest` on some files first.",
                file=sys.stderr,
            )
            return 1
        try:
            result = pipeline.query(args.question, top_k=args.top_k)
        except (EmbeddingError, GenerationError) as exc:
            print(f"Query failed: {exc}", file=sys.stderr)
            return 1

        print(result.answer)
        if args.show_sources and result.retrieved:
            print("\n--- sources ---")
            for i, r in enumerate(result.retrieved):
                print(f"[{i + 1}] score={r.score:.3f}  {r.chunk.source}")
        return 0

    return 1


if __name__ == "__main__":
    raise SystemExit(main())
