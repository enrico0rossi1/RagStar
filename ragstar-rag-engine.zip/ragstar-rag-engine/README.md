# ragstar-rag-engine

A from-scratch, local-first RAG (retrieval-augmented generation) engine — built as a personal learning project, deliberately without LangChain/LlamaIndex, so every stage is plain, readable code you can step through: loading → chunking → embedding → vector search → prompt assembly → generation.

See `../ADR-0001-rag-on-dwarfstar.md` for the reasoning behind the architecture choices here (why no framework, why the generation client is OpenAI-compatible instead of DwarfStar-specific, why embeddings are a separate concern from generation).

## Why it's built this way

- **Generation talks to any OpenAI-compatible `/v1/chat/completions` server.** Today that's Ollama, running locally. Later it can be DwarfStar's `ds4-server` — change `RAGSTAR_CHAT_BASE_URL`, nothing else.
- **Embeddings are separate from generation, on purpose.** DwarfStar doesn't serve embeddings and has no plans to, so this stays pointed at Ollama (or another local embedding server) even after generation moves elsewhere.
- **The vector store is hand-rolled** (numpy + cosine similarity, no FAISS/Chroma/LanceDB) so nothing about "vector search" is hidden behind a library. Fine for a personal dataset; swap it out later if you ever need to scale past brute force.
- **Chunking is a plain recursive splitter** (paragraph → sentence → hard cut, with overlap) — the "Naive RAG" baseline from the RAG survey (arXiv:2312.10997). Smarter chunking is a natural next step once this works end to end.

## Setup

1. Install [Ollama](https://ollama.com) and start it: `ollama serve`
2. Pull a chat model and an embedding model:
   ```
   ollama pull llama3.2
   ollama pull nomic-embed-text
   ```
   (Change `chat_model` / `embed_model` in `rag_engine/config.py`, or via env vars, if you use different ones.)
3. Install Python dependencies:
   ```
   pip install -r requirements.txt
   ```

## Usage

```bash
# Ingest files or a whole directory (recurses, picks the right loader per extension)
python -m rag_engine.cli ingest sample_data/
python -m rag_engine.cli ingest ~/Documents/notes/

# Ask a question against everything you've ingested so far
python -m rag_engine.cli query "What is a group of cats called?"
python -m rag_engine.cli query "Summarize the ADR's recommendation" --top-k 6

# Wipe the index and start over
python -m rag_engine.cli reset
```

The index is stored under `.ragstar_index/` (a `vectors.npy` + `chunks.json` pair) in the current directory. Ingesting is additive — run it again on new files and they're added to the existing index.

## Supported formats

`.txt`, `.md`/`.markdown`, `.html`/`.htm`, `.pdf`, `.csv`, `.json` — see `sample_data/README.md` for what varied test data is included and why (and a note on why the PDF sample isn't a real arxiv paper).

## Swapping the backend to DwarfStar later

Once you have hardware that can run DwarfStar's supported models, start `ds4-server` and point generation at it — no code changes:

```bash
export RAGSTAR_CHAT_BASE_URL="http://localhost:8080/v1"
export RAGSTAR_CHAT_MODEL="<model name ds4-server reports at /v1/models>"
python -m rag_engine.cli query "..."
```

`RAGSTAR_EMBED_BASE_URL` stays pointed at Ollama (or wherever you're running embeddings) — DwarfStar doesn't serve embeddings.

All env vars: `RAGSTAR_CHAT_BASE_URL`, `RAGSTAR_CHAT_MODEL`, `RAGSTAR_CHAT_API_KEY`, `RAGSTAR_EMBED_BASE_URL`, `RAGSTAR_EMBED_MODEL`, `RAGSTAR_EMBED_API_KEY`, `RAGSTAR_CHUNK_SIZE`, `RAGSTAR_CHUNK_OVERLAP`, `RAGSTAR_TOP_K`, `RAGSTAR_INDEX_DIR` (see `rag_engine/config.py`).

## Testing

No real Ollama is required for the automated tests — they run against a small fake OpenAI-compatible HTTP server (`tests/fake_openai_server.py`) that fakes embeddings with a deterministic word-hashing trick, just accurate enough to prove the retrieval logic actually works (not just "doesn't crash").

```bash
python3 -m tests.test_pipeline_smoke -v
```

This does **not** replace checking real answer quality once Ollama is running — the fake embeddings are a wiring check, not a quality check.

## Known limitations / honest state of things

This is a "Naive RAG" baseline, on purpose, to get something working end to end before adding complexity. Not yet implemented (natural next steps, roughly in order of likely value):

- Query rewriting / expansion (helps a lot when the user's phrasing doesn't match the document's phrasing)
- Reranking retrieved chunks before generation (cheap, meaningfully improves precision)
- Structure-aware chunking for code and deeply nested JSON
- A real evaluation harness (retrieval precision/recall, answer faithfulness — see the RAG survey's evaluation section, e.g. RAGAS-style metrics) instead of eyeballing answers
- Streaming responses instead of waiting for the full completion
- Any kind of persistence beyond a single flat index (no multi-collection support, no incremental re-embedding on file changes)
